import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { createPost, fetchPosts } from '../store/postSlice';
import { useNavigate } from 'react-router-dom';

const CreatePost = () => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [error, setError] = useState(null);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    setError(null);
    const trimmedTitle = title.trim();
    const trimmedContent = content.trim();
    if (!trimmedTitle || !trimmedContent) {
      setError('Title and content cannot be empty');
      return;
    }
    console.log('Submitting post:', { title: trimmedTitle, content: trimmedContent });
    dispatch(createPost({ title: trimmedTitle, content: trimmedContent }))
      .unwrap()
      .then(() => {
        setContent('');
        setTitle('');
        dispatch(fetchPosts());
        navigate('/posts');
      })
      .catch((err) => {
        console.error('Create post error:', err);
        setError(err || 'Failed to create post');
      });
  };

  return (
    <div>
      <h2>Create New Post</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
        <textarea
          placeholder="Content"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          required
        />
        <button type="submit">Post</button>
      </form>
    </div>
  );
};

export default CreatePost;