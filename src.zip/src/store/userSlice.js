import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { jwtDecode } from 'jwt-decode';

const API = 'http://127.0.0.1:5000';

export const loginUser = createAsyncThunk('user/loginUser', async (userData, thunkAPI) => {
  try {
    console.log('Sending POST /login with data:', userData);
    const res = await axios.post(`${API}/login`, userData);
    console.log('Received token from /login:', res.data.access_token);
    localStorage.setItem('token', res.data.access_token);
    return res.data.access_token;
  } catch (err) {
    console.error('Error in loginUser:', err.response?.data);
    return thunkAPI.rejectWithValue(err.response.data.message);
  }
});

export const registerUser = createAsyncThunk('user/registerUser', async (userData, thunkAPI) => {
  try {
    console.log('Sending POST /register with data:', userData);
    const res = await axios.post(`${API}/register`, userData);
    console.log('Response from /register:', res.data);
    return res.data.message;
  } catch (err) {
    console.error('Error in registerUser:', err.response?.data);
    return thunkAPI.rejectWithValue(err.response.data.message);
  }
});

export const fetchUsers = createAsyncThunk('user/fetchUsers', async (_, thunkAPI) => {
  try {
    const token = thunkAPI.getState().user.token;
    console.log('Sending GET /users with token:', token);
    const res = await axios.get(`${API}/users`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return res.data;
  } catch (err) {
    console.error('Error in fetchUsers:', err.response?.data);
    return thunkAPI.rejectWithValue(err.response.data.message);
  }
});

export const deleteUser = createAsyncThunk('user/deleteUser', async (id, thunkAPI) => {
  try {
    const token = thunkAPI.getState().user.token;
    console.log('Sending DELETE /users with ID:', id, 'Token:', token);
    await axios.delete(`${API}/users/${id}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return id;
  } catch (err) {
    console.error('Error in deleteUser:', err.response?.data);
    return thunkAPI.rejectWithValue(err.response.data.message);
  }
});

export const logoutUser = () => (dispatch) => {
  console.log('Logging out user');
  localStorage.removeItem('token');
  dispatch(logout()); // Fixed typo: 'dispatching' -> 'dispatch'
};

const userSlice = createSlice({
  name: 'user',
  initialState: {
    token: localStorage.getItem('token') || null,
    currentUser: null,
    role: null,
    status: null,
    error: null,
    allUsers: [],
  },
  reducers: {
    logout: (state) => {
      state.token = null;
      state.currentUser = null;
      state.role = null;
      localStorage.removeItem('token');
    },
    loadUser: (state) => {
      const token = localStorage.getItem('token');
      console.log('Loading user, token from localStorage:', token);
      if (token) {
        try {
          const decoded = jwtDecode(token);
          console.log('Decoded token:', decoded);
          const userData = decoded.sub; // Access the 'sub' field
          state.token = token;
          state.currentUser = { id: userData.id, role: userData.role, username: userData.username };
          state.role = userData.role;
        } catch (err) {
          console.error('Error decoding token:', err);
          localStorage.removeItem('token');
          state.token = null;
          state.currentUser = null;
          state.role = null;
        }
      } else {
        console.log('No token found in localStorage');
      }
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchUsers.fulfilled, (state, action) => {
        state.allUsers = action.payload;
      })
      .addCase(deleteUser.fulfilled, (state, action) => {
        state.allUsers = state.allUsers.filter((user) => user.id !== action.payload);
      })
      .addCase(loginUser.fulfilled, (state, action) => {
        state.token = action.payload;
        const decoded = jwtDecode(action.payload);
        console.log('Decoded token after login:', decoded);
        const userData = decoded.sub; // Access the 'sub' field
        state.currentUser = { id: userData.id, role: userData.role, username: userData.username };
        state.role = userData.role;
        state.status = 'succeeded';
      })
      .addCase(loginUser.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload;
      })
      .addCase(registerUser.fulfilled, (state) => {
        state.status = 'registered';
      })
      .addCase(registerUser.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload;
      });
  },
});

export const { logout, loadUser } = userSlice.actions;
export default userSlice.reducer;